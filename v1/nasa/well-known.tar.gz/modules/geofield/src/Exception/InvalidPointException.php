<?php

namespace Drupal\geofield\Exception;

/**
 * Defines 'invalid point' exception class.
 */
class InvalidPointException extends \InvalidArgumentException {

}
