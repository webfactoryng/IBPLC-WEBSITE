<?php

namespace Drupal\geofield\Exception;

/**
 * Defines 'proximity value is unavailable' exception class.
 */
class ProximityUnavailableException extends \UnexpectedValueException {

}
