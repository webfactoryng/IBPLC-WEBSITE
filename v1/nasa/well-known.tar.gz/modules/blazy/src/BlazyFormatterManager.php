<?php

namespace Drupal\blazy;

/**
 * Provides common field formatter-related methods: Blazy, Slick, etc.
 *
 * @todo deprecate this for just BlazyFormatter at blazy:8.2.1.
 */
class BlazyFormatterManager extends BlazyFormatter {}
